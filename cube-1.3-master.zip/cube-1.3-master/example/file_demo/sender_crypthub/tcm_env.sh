#!/bin/sh
export TCM_SERVER_NAME=$1
export TCM_SERVER_PORT=$2
