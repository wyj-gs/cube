#ifndef KEY_MANAGE2_H
#define KEY_MANAGE2_H

int key_manage2_init(void * sub_proc,void * para);
int key_manage2_start(void * sub_proc,void * para);

#endif
