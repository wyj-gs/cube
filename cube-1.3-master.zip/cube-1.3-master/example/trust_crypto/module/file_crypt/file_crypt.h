#ifndef KEY_REQUEST1_H
#define KEY_REQUEST1_H

int file_crypt_init(void * sub_proc,void * para);
int file_crypt_start(void * sub_proc,void * para);

#endif
