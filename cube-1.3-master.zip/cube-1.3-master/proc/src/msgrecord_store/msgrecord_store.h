#ifndef MSGRECORD_STORE_H
#define MSGRECORD_STORE_H
 
 
int msgrecord_store_init (void * sub_proc, void * para);
int msgrecord_store_start (void * sub_proc, void * para);
#endif
